export interface Villages {
	village : string,
};

export interface District {
	district : string,
};

export interface Kaza {
	kaza : string,  
};

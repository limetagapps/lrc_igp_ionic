export interface Donations {
	id: string,
	dollar : string,
	value : string,
	subscription : string,
	subscriptionContent : boolean,
}
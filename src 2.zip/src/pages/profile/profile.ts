import $ from "jquery";

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
	profileTitle: boolean;
	addressTitle: boolean;
	donationTitle: boolean;
	headerProfile = true;
	donatedContainer: boolean;
	profileContent: boolean;
  donationContent : boolean;
  addressContent : boolean;
  isarrowdown = false;
  isarrowdown2 = false;
  isarrowdown3 = false;
  buttonwidth = '100%';
  padtop ='64px';
  padbot='30px';
  padleft='30px';
  padright='30px'; 
  constructor(public navCtrl: NavController, public navParams: NavParams) {

	this.profileContent = false;
  this.donationContent = false;
  this.addressContent = false;

	this.donatedContainer = true;

  $('ion-fab')[0].style.display = 'none';
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }

  profileBtn(){

    this.padtop = '0px';
    this.padleft = '10px';
    this.padright = '10px';
    this.buttonwidth = '100%';
    this.headerProfile = false;
    this.profileTitle = true

  	if(this.profileContent == false){
  	
    this.isarrowdown = true;
		this.profileContent = true;

  	}else{
  	
    this.isarrowdown = false;  
		this.profileContent = false;

  	}
  	
  }

  addressBtn(){

    this.padtop = '0px';
    this.padleft = '10px';
    this.padright = '10px';
    this.buttonwidth = '100%';
    this.headerProfile = false;
    this.profileTitle = true

    if(this.addressContent == false){
    
    this.isarrowdown2 = true;
    this.addressContent = true;

    }else{
    
    this.isarrowdown2 = false;    
    this.addressContent = false;

    }

  }
  donationBtn(){

    this.padtop = '0px';
    this.padleft = '10px';
    this.padright = '10px';
    this.buttonwidth = '100%';
    this.headerProfile = false;
    this.profileTitle = true

    if(this.donationContent == false){
    
    this.isarrowdown3 = true;
    this.donationContent = true;

    }else{
    
    this.isarrowdown3 = false;
    this.donationContent = false;

    }

  }
}

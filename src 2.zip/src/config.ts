//config constants
export const WORDPRESS_URL = 'https://supportlrc.app/';// 'http://54.93.99.219/wordpress/';
export const WORDPRESS_REST_API_URL = WORDPRESS_URL + 'wp-json/wp/v2/';

export interface Video {
	author : string;
	authorIcon : string;
	videoThumbnail: string;
	title: string;
	description: string;
	videoId: string;
}